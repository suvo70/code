import React, { useState, useEffect } from "react";
import axios from "axios";
import { Card, Container, Row, Col } from "react-bootstrap";
import "./ProductDtlStyle.css";

function ProductDetails({ match }) {
  const [productState, setproductState] = useState({
    productDetails: [],
  });
  const dlsName = match.params.subId;
  console.log("CatName: ", dlsName);
  useEffect(() => {
    axios
      .get(`https://fakestoreapi.com/products/${dlsName}`)
      .then((res) => {
        console.log("SubCat: ", res);
        setproductState({ productDetails: res.data });
      })
      .catch(
        (err) => {
          console.log(err);
        },
        [setproductState]
      );
  }, []);
  return (
    <div>
      <Card border="primary" key={productState.productDetails.id}>
        <Card.Body>
          <Container>
            <Row>
              <Col>
                <Card.Img
                  variant="top"
                  src={productState.productDetails.image}
                  className="img-pro"
                />
              </Col>
              <Col>
                <ul>
                  <Card.Title className="title-pro">
                    {productState.productDetails.title}
                  </Card.Title>

                  <li>
                    <Card.Text className="position-pro">
                      <h1 className="font-pro">Price :</h1>
                      {productState.productDetails.price}
                    </Card.Text>
                  </li>
                  <li>
                    <Card.Text className="position-pro">
                      <h1 className="font-pro">Description:</h1>
                      {productState.productDetails.description}
                    </Card.Text>
                  </li>
                  {/* <li>
                    <Card.Text>
                      {itemState.itemDetails.rating}
                      {itemState.itemDetails.count}
                      {itemState.itemDetails.map((pro) => {
              <h1>
                {pro.rate}
                {pro.count}
              </h1>;
            })}
                    </Card.Text>
                  </li> */}
                </ul>
              </Col>
            </Row>
          </Container>
        </Card.Body>
      </Card>
    </div>
  );
}

export default ProductDetails;
