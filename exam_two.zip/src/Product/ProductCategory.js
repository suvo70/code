import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { Card, Row, Col, Button } from "react-bootstrap";
import "./ProductCatStyle.css";

function ProductCatagory() {
  const [productState, setproductState] = useState({
    productData: [],
  });
  useEffect(() => {
    axios
      .get("https://fakestoreapi.com/products")
      .then((res) => {
        console.log("poducts: ", res);
        setproductState({ productData: res.data });
      })
      .catch((err1) => {
        console.log(err1);
      });
  }, [setproductState]);
  return (
    <div className="back-ground">
      {productState.productData.map((items) => (
        <Row xs={1} md={2} className="g-4 control">
          {Array.from({ length: 1 }).map((_, idx) => (
            <Col className="position">
              <Card className="redi">
                <Card.Img
                  variant="left"
                  src={items.image}
                  className="img-siz"
                />
                <Card.Body>
                  <Card.Title>
                    <h1 className="text-format">{items.title}</h1>
                  </Card.Title>
                  <Card.Title>
                    <h1 className="text-format-cat">{items.category}</h1>
                  </Card.Title>
                  <Button className="btn-position">
                    <Link
                      key={items.id}
                      to={`/ProductDetails_page/${items.id}`}
                      style={{
                        color: "#fff",
                      }}
                    >
                      <h1 className="btn-tx">Details</h1>
                    </Link>
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      ))}
    </div>
  );
}

export default ProductCatagory;
