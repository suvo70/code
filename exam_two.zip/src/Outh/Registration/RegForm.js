import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import { Container, Row, Col } from "react-bootstrap";
import "./RegFormStyle.css";
import axios from "axios";

function RegForm() {
  let history = useHistory();
  const validateEmail = RegExp("^([a-z0-9.-]+)@([a-z]{5,12}).([a-z.]{2,20})$");
  const validatePassword = RegExp(
    "^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9])(?=.*[a-z]).{4,12}$"
  );
  const validatePhone = RegExp("[7-9]{1}[0-9]{9}");
  const [inputState, setInputState] = useState({
    isError: {
      firstname: "",
      lastname: "",
      phone: "",
      state_name: "",
      city_name: "",
      email: "",
      password: "",
    },
  });
  function handleClick() {
    history.push("/ProductCategory_page");
  }
  const handleChange = (event) => {
    event.persist();

    let { name, value } = event.target;
    let isErr = { ...inputState.isError };
    switch (name) {
      case "firstname":
        isErr.firstname =
          value.length < 3 ? "Atleast 3 characters required" : "";
        break;
      case "lastname":
        isErr.lastname =
          value.length < 3 ? "Atleast 3 characters required" : "";
        break;
      case "phone":
        isErr.phone = validatePhone.test(value)
          ? value.length > 10
            ? "Invalid Phone Number"
            : "Atleast 10 number required"
          : "Invalid Phone Number";
        break;
      case "state_name":
        isErr.state_name =
          value.length < 3 ? "Atleast 3 characters required" : "";

        break;
      case "city_name":
        isErr.city_name =
          value.length < 3 ? "Atleast 3 characters required" : "";

        break;
      case "email":
        isErr.email = validateEmail.test(value) ? "" : "Wrong Pattern";
        break;
      case "password":
        isErr.password = validatePassword.test(value) ? "" : "Wrong Pattern";
        break;
      default:
        break;
    }
    setInputState({ ...inputState, [name]: value, isError: isErr });
    console.log(inputState);
  };

  const submitHandler = (event) => {
    event.preventDefault();
    console.log("After submit: ", inputState);
    const user = inputState;

    axios
      .post("https://jsonplaceholder.typicode.com/users", user)

      .then((res) => {
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  return (
    <div className="font_style">
      <h1>Registration page</h1>
      <form onSubmit={submitHandler}>
        <Container>
          <Row>
            <Col>
              <label className="label_style">First name</label>
              <input
                type="text"
                placeholder="ABC"
                name="firstname"
                onChange={handleChange}
                className="input_style"
              />
              {inputState.isError.firstname.length > 0 && (
                <span>
                  <br />
                  {inputState.isError.firstname}
                </span>
              )}
            </Col>
            <Col>
              <label className="label_style">Last name</label>

              <input
                type="text"
                placeholder="abc"
                name="lastname"
                onChange={handleChange}
                required
                className="input_style"
              />
              {inputState.isError.lastname.length > 0 && (
                <span>
                  <br />
                  {inputState.isError.lastname}
                </span>
              )}
            </Col>
          </Row>
          <Row>
            <Col>
              <label className="label_style phone">Phone Number</label>

              <input
                type="number"
                placeholder="0123456789"
                name="phone"
                onChange={handleChange}
                className="input_style"
              />
              {inputState.isError.phone.length > 0 && (
                <span className="show">
                  <br />
                  {inputState.isError.phone}
                </span>
              )}
            </Col>
          </Row>
          <Row>
            <Col>
              <label className="label_style phone">State name</label>

              <input
                type="text"
                placeholder="--select your state--"
                name="state_name"
                onChange={handleChange}
                list="state"
                className="input_style"
              />
              <datalist id="state">
                <option>West Bengal</option>
                <option>Bihar</option>
                <option>Rajasthan</option>
                <option>Kerala</option>
              </datalist>
              {inputState.isError.state_name.length > 0 && (
                <span className="show">
                  <br />
                  {inputState.isError.state_name}
                </span>
              )}
            </Col>

            <Col>
              <label className="label_style phone">City</label>

              <input
                type="text"
                placeholder="--enter yor city name--"
                name="city_name"
                onChange={handleChange}
                className="input_style"
              />
              {inputState.isError.city_name.length > 0 && (
                <span className="show">
                  <br />
                  {inputState.isError.city_name}
                </span>
              )}
            </Col>
          </Row>
          <Row>
            <Col>
              {" "}
              <label className="label_style email">Email Id</label>
              <input
                type="email"
                placeholder="abc@email.com"
                name="email"
                onChange={handleChange}
                className="input_style"
              />
              {inputState.isError.email.length > 0 && (
                <span>
                  <br />
                  {inputState.isError.email}
                </span>
              )}
            </Col>
            <Col>
              {" "}
              <label className="label_style pass">Password</label>
              <input
                type="password"
                placeholder="password"
                name="password"
                onChange={handleChange}
                className="input_style"
              ></input>
              {inputState.isError.password.length > 0 && (
                <span>
                  <br />
                  {inputState.isError.password}
                </span>
              )}
            </Col>
          </Row>
          <Row>
            <Col>
              <button
                variant="promary"
                type="submit"
                className="btn_style"
                onClick={handleClick}
              >
                Submit
              </button>
            </Col>
          </Row>
        </Container>
      </form>
    </div>
  );
}

export default RegForm;
