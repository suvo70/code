import { Route, Switch, BrowserRouter as Router } from "react-router-dom";
import Header from "../LayOut/Header/Header";
import Home from "../Components/Home/Home";
import About from "../Components/About/About";
import ProductCategory from "../Product/ProductCategory";
import ProductDetails from "../Product/ProductDetails";
import RegForm from "../Outh/Registration/RegForm";

function RootRoute() {
  return (
    <Router>
      <Header />
      <Switch>
        <Route exact path="/home_page" component={Home}></Route>
        <Route path="/about_page" component={About}></Route>
        <Route path="/ProductCategory_page" component={ProductCategory} />
        <Route path="/ProductDetails_page/:subId" component={ProductDetails} />
        <Route path="/Registration_page" component={RegForm} />
        <Route render={() => <h1>404: Page not found!!!</h1>}></Route>
      </Switch>
    </Router>
  );
}

export default RootRoute;
